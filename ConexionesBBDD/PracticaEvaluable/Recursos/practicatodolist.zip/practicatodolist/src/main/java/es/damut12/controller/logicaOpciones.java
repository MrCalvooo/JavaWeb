package es.damut12.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import es.damut12.model.Tarea;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet(value = "/opcionesL")
public class logicaOpciones extends HttpServlet {


    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
        //con qué opción se llama a este servlet
        
        switch (opcion) {
            case ver:
            {
                //lógica necesaria. Pensar en gestionar llamando a otros métodos para modularizar
				//envío al jsp de respuesta lo que quiera
				//llamo al jsp que quiero que se muestre
                break;
            }    
                
            case insertar:
            {
                //recojo informacion de opciones.jsp
                //lógica relacionada con la inserción. Pensar en gestionar llamando a otros métodos para modularizar
                //envío al jsp de respuesta lo que quiera
				//llamo al jsp que quiero que se muestre
                break;
            }
            case eliminar:
            {
                //recojo informacion de opciones.jsp
                //lógica relacionada con la eliminación. Pensar en gestionar llamando a otros métodos para modularizar
                //envío al jsp de respuesta lo que quiera
				//llamo al jsp que quiero que se muestre
                break;
            }
        }
    }

	//estructura métodos que modularizan las opciones
    public void opcionElegida(parametros que necesite)
    {

            Class.forName("org.sqlite.JDBC");
            //conexión String url ruta absoluta tareas.db
            
            //consulta o consultas que necesite realizar
            
            //conecto
            
			//completo consulta si lo necesito
			
            //ejecuto sentencia guardando en ResultSet o recibiendo en un int resultado que compruebe
        
    }


}
