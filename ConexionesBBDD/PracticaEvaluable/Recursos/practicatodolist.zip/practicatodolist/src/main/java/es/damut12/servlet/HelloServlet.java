/*
 * Copyright 2020 Diego Silva <diego.silva at apuntesdejava.com>.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package es.damut12.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import es.damut12.model.Tarea;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {



    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
        //cojo la información que me llega de index.jsp


        //conecto con la base de datos
        
		//consulta para ver si el usuario está y se loguea bien
	   
		//conexión con la base de datos
		
		//ejecuto la sentencia y guardo lo que me devuelva
			
			
		//el usuario se ha logueado bien. Existe en la base de datos
	   
		//envío a la página de opciones
		

		//el usuario no se ha identificado bien/no existe en la base de datos


    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
    {
		//los .jsp incluidos en /WEB-INF/views no son visibles desde el navegador por cuestiones de seguridad
		//el servidor Tomcat no permite el acceso directo a ellos
		//por eso, si queremos redirigir desde esos.jsp, tendremos que hacerlo pasando por el Servlet
		//esas redirecciones el Servlet las gestiona desde el método doGet
		//debes controlar aquí si quieres enviar algo a otro .jsp
		//y el .forward al .jsp que corresponda
        
    }


}